const chalk = require("chalk")
const fs = require("fs")

//owmner v card
global.owner = ['6283853532520'] //ur owner number
global.ownernomer = "6283853532520" //ur owner number2
global.ownername = "Arya" //ur owner name
global.ytname = "YT: arya Official" //ur yt chanel name
global.socialm = "GitHub: anjing" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.ownergc = "https://chat.whatsapp.com/G4e1btBevW3K0zh9tPHN2x"
global.botname = "Created By Arya"
global.ownerNumber = ["6283853532520@s.whatsapp.net"]
global.ownerweb = "https://www.youtube.com/@GARDEN"
global.themeemoji = '🪀'
global.wm = "aryabotz.my.id"
global.packname = "Sticker By"
global.author = "ary\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://telegra.ph/file/7b8832bbb4002b633a12c.jpg' }//ur thumb pic
global.defaultpp = 'https://telegra.ph/file/7b8832bbb4002b633a12c.jpg' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
